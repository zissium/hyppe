<div class="qodef-album" >
	<div class="qodef-album-inner" >
		<a class ="qodef-album-link" href="<?php echo esc_url($album_link); ?>"></a>
		<div class = "qodef-album-image-holder">
		<?php
			echo get_the_post_thumbnail(get_the_ID(),'full');
		?>				
		</div>
		<div class="qodef-album-text-overlay">
			<div class="qodef-album-text-overlay-inner">
				<div class="qodef-album-text-holder">
					<?php
						echo ($artist_html);
					?>
					<h4 class="qodef-album-title">
						<?php echo esc_attr(get_the_title()); ?>
					</h4>	
				</div>
			</div>	
		</div>
	</div>
	<?php
	if ($show_stores == 'yes'):
		$stores = get_post_meta(get_the_ID(), 'qodef_store_name', true);
		$stores_links = get_post_meta(get_the_ID(), 'qodef_store_link', true);
		$i = 0;
	?>
	<?php if(is_array($stores) && count($stores) > 0 && implode($stores) != ''): ?>
			<div class="qodef-album-stores clearfix">
				<?php
				foreach($stores as $store) :
				    if ( strpos($stores_list, $store) !== false ): ?>

					<span class="qodef-album-store">
						<?php if(isset($stores_links[$i]) && $stores_links[$i]) : ?>
							<a class="qodef-album-store-link" href="<?php echo esc_url($stores_links[$i]); ?>" target = "_blank">
								<?php echo qodef_fn_single_stores_names_and_images($store, 'image'); ?>
							</a>
						<?php else: ?>
							<?php echo qodef_fn_single_stores_names_and_images($store, 'image'); ?>
						<?php endif; ?>
					</span>
					<?php
					endif;
					$i++;
				endforeach;
				?>
			</div>
	<?php endif; 
	endif; ?>
</div>