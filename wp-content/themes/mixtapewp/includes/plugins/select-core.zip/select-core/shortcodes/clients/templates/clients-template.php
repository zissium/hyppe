<div class="qodef-clients clearfix qodef-clients-<?php echo esc_attr($columns); ?>">
	<?php echo do_shortcode($content); ?>
</div>