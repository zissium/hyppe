<?php

//Pie Chart Basic
include_once QODE_CORE_ABS_PATH.'/shortcodes/parallax-holder/parallax-holder.php';
