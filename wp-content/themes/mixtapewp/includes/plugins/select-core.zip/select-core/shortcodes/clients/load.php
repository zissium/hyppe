<?php
require_once QODE_CORE_ABS_PATH.'/shortcodes/clients/clients.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/clients/client.php';
