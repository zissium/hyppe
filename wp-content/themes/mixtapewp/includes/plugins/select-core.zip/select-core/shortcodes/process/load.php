<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/process/process-holder.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/process/process-item.php';
