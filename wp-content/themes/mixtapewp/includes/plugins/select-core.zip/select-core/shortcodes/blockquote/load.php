<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/blockquote/options-map/map.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/blockquote/blockquote.php';