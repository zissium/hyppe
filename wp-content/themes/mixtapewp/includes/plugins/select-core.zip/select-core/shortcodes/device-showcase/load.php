<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/device-showcase/device-showcase.php';
