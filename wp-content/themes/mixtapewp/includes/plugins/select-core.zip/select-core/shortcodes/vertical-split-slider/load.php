<?php
require_once QODE_CORE_ABS_PATH.'/shortcodes/vertical-split-slider/vertical-split-slider.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/vertical-split-slider/vertical-split-slider-left-panel.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/vertical-split-slider/vertical-split-slider-right-panel.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/vertical-split-slider/vertical-split-slider-content-item.php';