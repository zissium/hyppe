<div class="qodef-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="qodef-separator" <?php echo mixtape_qodef_get_inline_style($separator_style); ?>></div>
</div>
