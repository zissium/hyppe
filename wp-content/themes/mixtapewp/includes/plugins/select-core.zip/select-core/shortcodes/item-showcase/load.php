<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/item-showcase/item-showcase.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/item-showcase/item-showcase-list-item.php';
