<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/customfont/custom-font.php';