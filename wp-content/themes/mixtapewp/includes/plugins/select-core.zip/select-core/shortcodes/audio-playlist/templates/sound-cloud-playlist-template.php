<div class="qodef-audio-playlist-holder">
    <iframe width="100%" height="350" scrolling="no" frameborder="no"
            src="<?php print esc_url( $playlist_id_url ); ?>"></iframe>
</div>
