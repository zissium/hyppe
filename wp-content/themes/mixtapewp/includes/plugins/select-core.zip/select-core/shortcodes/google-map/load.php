<?php
include_once QODE_CORE_ABS_PATH.'/shortcodes/google-map/google-map-functions.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/google-map/google-map.php';

