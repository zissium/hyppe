<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/audio-playlist/audio-playlist-functions.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/audio-playlist/options-map/map.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/audio-playlist/audio-playlist.php';