<div class="qodef-audio-playlist-holder">
    <iframe style="border: 0; width: 100%; height: 350px;"
            src="<?php print esc_url( $playlist_id_url ); ?>" seamless></iframe>
</div>