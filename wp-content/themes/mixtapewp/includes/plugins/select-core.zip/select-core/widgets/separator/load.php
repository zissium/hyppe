<?php

require_once 'separator.php';