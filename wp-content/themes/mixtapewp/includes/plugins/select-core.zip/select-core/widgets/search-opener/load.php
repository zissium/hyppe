<?php

require_once 'search-opener.php';
