<?php

require_once 'latest-posts.php';