<?php

if ( qodef_core_is_woocommerce_installed() ) {
	require_once 'woo-dd-cart.php';
}