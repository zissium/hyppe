<?php

require_once 'side-area-opener.php';